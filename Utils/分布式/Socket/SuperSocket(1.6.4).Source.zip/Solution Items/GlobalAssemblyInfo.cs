﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("1.6.4.0")]
[assembly: AssemblyFileVersion("1.6.4.0")]
[assembly: AssemblyCompany("SuperSocket")]
[assembly: AssemblyProduct("SuperSocket")]
[assembly: AssemblyCopyright("Copyright © supersocket.codeplex.com 2010-2014")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]