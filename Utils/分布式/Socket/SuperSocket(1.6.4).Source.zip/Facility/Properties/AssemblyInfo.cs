﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SuperSocket.Facility")]
[assembly: AssemblyDescription("SuperSocket.Facility")]
[assembly: AssemblyConfiguration("")]
[assembly: ComVisible(false)]
[assembly: Guid("341d2163-09a9-4f60-813f-366405715898")]
